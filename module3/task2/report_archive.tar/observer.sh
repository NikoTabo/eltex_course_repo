#!/bin/bash

CONFIG_FILE="/home/eltex-pg1-v5/practice3/scripts.conf"
LOG_FILE="/home/eltex-pg1-v5/practice3/observer.log"

# Чтение конфигурационного файла построчно
while IFS= read -r script_path; do
    # Проверка, запущен ли скрипт
    if ! pgrep -f "$script_path" > /dev/null; then
        nohup "$script_path" > /dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') - [INFO] Скрипт '$script_path' был перезапущен." >> "$LOG_FILE"
    fi
done < "$CONFIG_FILE"